# Tamil Mp3 Downloader (In Single Click)
Download thousands of High Quality MP3 (320kbps) in a single run. You can download specific songs based on their hits.

### 🎼 [Mp3 Downloader Pro](https://github.com/anburocky3/mp3-downloader) (Latest & Its Free!)
#### If you want to download songs in different language, checkout our latest project </br>

  

### ✅ [Download this script](https://github.com/anburocky3/tamil-mp3-downloader/fork)

> **Use this script with caution.** We don't support piracy and this project is completely for educational purposes only. Use it with care.🥰💖 

### Screenshots
![Screenshot 1](/screenshots/6.png)

### How to use this script?

1. [Clone this repository](https://github.com/anburocky3/tamil-mp3-downloader/fork) and open `Terminal` & go to this directory by `cd tamil-mp3-downloader`
2. Make sure you have [Python V3+](https://www.python.org/downloads/) and you check confirm, if you already have python by opening `Terminal` and type the following command. `python -v`. This should print the python version, if not, you don't have it and you have to install it (See step 2).
3. Install the dependencies
```bash
# for checking
python -v # check if python version is printing
pip -v # check if you have pip installed.

#installing dependencies, that are needed, inorder to work.
pip install -r requirements.txt
```
4. Run the python script
```bash
python main-classic.py
```
### Installation screenshots
![Screenshot 1](/screenshots/classic/1.png)
![Screenshot 2](/screenshots/classic/2.png)
![Screenshot 3](/screenshots/classic/3.png)
![Screenshot 4](/screenshots/classic/4.png)
![Screenshot 5](/screenshots/classic/5.png)
![Screenshot 6](/screenshots/classic/6.png)

#### License: [MIT](/LICENSE)

#### Author: [Anbuselvan Rocky](https://fb.me/anburocky3)
